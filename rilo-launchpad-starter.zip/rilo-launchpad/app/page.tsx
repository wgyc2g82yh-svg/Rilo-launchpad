"use client";

import { FormEvent, useEffect, useState } from "react";

type Status = { kind: "idle" | "loading" | "success" | "error"; message?: string };

export default function Home() {
  const [role, setRole] = useState("Token Creator");
  const [status, setStatus] = useState<Status>({ kind: "idle" });
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/waitlist")
      .then((res) => res.json())
      .then((data) => {
        if (typeof data.count === "number") setCount(data.count);
      })
      .catch(() => {});
  }, []);

  async function joinWaitlist(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setStatus({ kind: "loading" });
    const form = new FormData(event.currentTarget);
    const payload = {
      email: String(form.get("email") ?? ""),
      wallet: String(form.get("wallet") ?? ""),
      role,
    };

    try {
      const response = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error || "Something went wrong.");
      setStatus({ kind: "success", message: "You're on the list. We'll be in touch." });
      event.currentTarget.reset();
      setCount((current) => current === null ? null : current + 1);
    } catch (error) {
      setStatus({
        kind: "error",
        message: error instanceof Error ? error.message : "Please try again.",
      });
    }
  }

  return (
    <main>
      <nav className="nav shell">
        <a className="brand" href="#" aria-label="RILO home">
          <span className="brand-mark">R</span><span>RILO</span>
        </a>
        <div className="nav-links">
          <a href="#how-it-works">How it works</a>
          <a href="#ecosystem">Ecosystem</a>
          <a className="nav-cta" href="#waitlist">Get early access <span>↗</span></a>
        </div>
      </nav>

      <section className="hero shell">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse" /> BUILT FOR THE SOLANA ECOSYSTEM</div>
          <h1>Good projects<br />deserve <em>momentum.</em></h1>
          <p className="hero-sub">A new way to discover, support, and accelerate token launches on Solana. Get in early and help shape what comes next.</p>
          <div className="hero-actions">
            <a className="button button-primary" href="#waitlist">Join the waitlist <span>↗</span></a>
            <a className="text-link" href="#how-it-works">Explore RILO <span>↓</span></a>
          </div>
          <div className="social-proof">
            <div className="avatar-stack"><span>R</span><span>◎</span><span>↗</span></div>
            <div><strong>{count === null ? "Early access is open" : `${count.toLocaleString()} on the list`}</strong><small>Be part of the first wave</small></div>
          </div>
        </div>

        <div className="hero-art" aria-label="Abstract RILO launch acceleration graphic">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="orb-core"><span>R</span><i>↗</i></div>
          <div className="float-card card-top"><span className="mini-icon">↗</span><div><small>LAUNCH STATUS</small><strong>Building momentum</strong></div><span className="status-dot"></span></div>
          <div className="float-card card-bottom"><div className="chart-label"><small>PROJECT TRACTION</small><strong>Made to move forward</strong></div><svg viewBox="0 0 240 55" role="img" aria-label="Decorative rising line chart"><path d="M2 47 C28 43 31 34 52 38 S82 20 103 29 S133 14 154 22 S190 5 238 4" fill="none" stroke="#b8ff6b" strokeWidth="2.5" strokeLinecap="round"/><path d="M2 47 C28 43 31 34 52 38 S82 20 103 29 S133 14 154 22 S190 5 238 4 L238 55 L2 55Z" fill="url(#fade)"/><defs><linearGradient id="fade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#b8ff6b" stopOpacity=".2"/><stop offset="1" stopColor="#b8ff6b" stopOpacity="0"/></linearGradient></defs></svg></div>
          <div className="art-caption"><span className="caption-line"></span> THE NEXT WAVE STARTS HERE</div>
        </div>
        <div className="hero-bottom"><span>01 / DISCOVER</span><span>02 / ACCELERATE</span><span>03 / LAUNCH</span><span className="bottom-note">EARLY ACCESS · 2026</span></div>
      </section>

      <section className="ticker-strip"><div className="ticker-inner"><span>BUILT ON SOLANA</span><b>✳</b><span>MADE FOR MOMENTUM</span><b>✳</b><span>POWERED BY COMMUNITY</span><b>✳</b><span>BUILT ON SOLANA</span><b>✳</b><span>MADE FOR MOMENTUM</span></div></section>

      <section className="section shell" id="how-it-works">
        <div className="section-heading"><div className="eyebrow">01 — THE RILO APPROACH</div><h2>From first spark<br />to <em>full momentum.</em></h2></div>
        <div className="steps">
          <article className="step"><span className="step-number">01</span><div className="step-icon">⌕</div><h3>Get discovered</h3><p>Bring promising Solana projects into one place where early supporters can find what is next.</p><span className="step-foot">DISCOVERY FIRST ↗</span></article>
          <article className="step"><span className="step-number">02</span><div className="step-icon">↗</div><h3>Build momentum</h3><p>Give project teams a place to present their vision and explore optional ways to grow visibility.</p><span className="step-foot">GROW WITH INTENT ↗</span></article>
          <article className="step"><span className="step-number">03</span><div className="step-icon">✳</div><h3>Launch together</h3><p>Connect creators and communities around launches, with a focus on transparency and participation.</p><span className="step-foot">COMMUNITY POWERED ↗</span></article>
        </div>
      </section>

      <section className="ecosystem" id="ecosystem"><div className="shell ecosystem-inner"><div><div className="eyebrow">02 — ONE ECOSYSTEM</div><h2>For the builders.<br /><em>For the early believers.</em></h2><p>Whether you're creating the next project or looking for what's next, RILO is being designed to bring the right people together.</p><a href="#waitlist" className="button button-light">Find your place <span>↗</span></a></div><div className="audience-list"><div><span className="audience-icon">⌘</span><span><strong>Token creators</strong><small>Share your project and apply for launch opportunities.</small></span><b>↗</b></div><div><span className="audience-icon">◉</span><span><strong>Traders & explorers</strong><small>Get early access to the project discovery experience.</small></span><b>↗</b></div><div><span className="audience-icon">✳</span><span><strong>Community members</strong><small>Join early and help shape the RILO community.</small></span><b>↗</b></div></div></div></section>

      <section className="waitlist-section shell" id="waitlist">
        <div className="waitlist-glow"></div>
        <div className="waitlist-copy"><div className="eyebrow"><span className="pulse" /> EARLY ACCESS IS OPEN</div><h2>Be there<br />before <em>the launch.</em></h2><p>Get on the RILO list for launch updates, early access, and the chance to be part of what's coming to Solana.</p><div className="waitlist-perks"><span>✓ Product updates</span><span>✓ Early-access announcements</span><span>✓ Creator application access</span></div></div>
        <form className="waitlist-form" onSubmit={joinWaitlist}>
          <div className="form-top"><span className="form-step">RILO / EARLY ACCESS</span><span className="form-open"><i></i> OPEN</span></div>
          <h3>Get on the list.</h3><p>Be first to hear when RILO is ready.</p>
          <label htmlFor="email">Email address <span>*</span></label><input id="email" name="email" type="email" placeholder="you@example.com" autoComplete="email" required maxLength={254}/>
          <label htmlFor="role">I’m joining as a...</label><select id="role" value={role} onChange={(e) => setRole(e.target.value)}><option>Token Creator</option><option>Trader</option><option>Community Member</option></select>
          <label htmlFor="wallet">Solana wallet <small>OPTIONAL</small></label><input id="wallet" name="wallet" placeholder="Your public wallet address" autoComplete="off" maxLength={100}/>
          <button className="button button-primary submit-button" type="submit" disabled={status.kind === "loading"}>{status.kind === "loading" ? "Joining..." : "Join the waitlist"} <span>↗</span></button>
          {status.message && <div className={`form-message ${status.kind}`} role="status">{status.message}</div>}
          <small className="privacy-note">By joining, you agree to receive RILO launch updates. No wallet connection or transaction is required.</small>
        </form>
      </section>

      <footer className="footer shell"><a className="brand" href="#"><span className="brand-mark">R</span><span>RILO</span></a><span className="footer-tag">ACCELERATE WHAT'S NEXT.</span><span className="footer-copy">© 2026 RILO. Demo experience.</span></footer>
    </main>
  );
}
