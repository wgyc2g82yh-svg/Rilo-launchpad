import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "RILO — Accelerate Your Launch",
  description: "A Solana launch acceleration platform. Join the RILO early-access waitlist.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
